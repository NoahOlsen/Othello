#include <iostream>
#include <cstdlib>
#include <utility>
#include "AIplayer.h"
#include "Board.h"
#include "Cell.h"

using namespace std;

pair<int, int> AIplayer::move1(displayBoard AImove) {
    // declare variables
    Cell check;
    int x = 0, y = 0;
    pair<int, int> AIpair;
    
    
    // loop until valid move is found
    for (int row = 0; row < 8; ++row) {
        for (int col = 0; col < 8; ++col) {
            if (check.isLegalPlacementfor(row, col, AImove.board, 'O', 'X')) {
                x = row;
                y = col;
            }
        }
    }
    AIpair.first = x;
    AIpair.second = y;
    return AIpair;
}


pair<int, int> AIplayer::move2(displayBoard AImove) {
    // declare variables
    Cell check;
    pair<int, int> AIpair;
    int x = 0;
    int y = 0;
    
    // chip gain
    int chips = 0;
    int temp = 0;
    // check each position for valid move
    for (int row = 0; row < 8; ++row) {
        for (int col = 0; col < 8; ++col) {
            if (check.isLegalPlacementfor(row, col, AImove.board, 'O', 'X')) {
                AImove.upCheck(row, col, 'O', false);
                temp = AImove.getDifference();
                AImove.downCheck(row, col, 'O', false);
                temp += AImove.getDifference();
                AImove.leftCheck(row, col, 'O', false);
                temp += AImove.getDifference();
                AImove.rightCheck(row, col, 'O', false);
                temp += AImove.getDifference();
                AImove.uprightCheck(row, col,'O', false);
                temp += AImove.getDifference();
                AImove.upleftCheck(row, col,'O', false);
                temp += AImove.getDifference();
                AImove.downrightCheck(row, col,'O', false);
                temp += AImove.getDifference();
                AImove.downleftCheck(row, col,'O', false);
                temp += AImove.getDifference();
                if (temp > chips) {
                    chips = temp;
                    y = row;
                    x = col;
                }
            }
        }
    }
    AIpair.first = x;
    AIpair.second = y;
    return AIpair;
}
