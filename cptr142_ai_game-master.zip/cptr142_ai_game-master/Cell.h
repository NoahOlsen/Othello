#ifndef CELL_H
#define CELL_H

#include <vector>
using namespace std;

class Cell {
    public:
        Cell(int x, int y) {this->x = x; this->y = y;}
        Cell() {this->x = 0; this->y = 0;}
        enum Directions{NORTH, NORTHEAST, EAST, SOUTHEAST, SOUTH, SOUTHWEST, WEST, NORTHWEST};
        bool isLegalPlacementfor(int x, int y, char board[][8], char playDisc, char oppDisc);
        int sequenceLength(Directions direction, char board[][8], char playDisc, string indent);
        bool isOccupied(char board[][8], char disc);
        int x, y;

};

#endif
