#include <iostream> // For cin and cout 
#include <utility>
#include "Board.h"
#include "AIplayer.h"
#include "Cell.h"
using namespace std;


int main() {
    int seed = 0; 
    int turn = 1;
    int difficulty = 0;
    int x, y;
    int aiX, aiY;
    pair<int, int> AImove;
    bool winner = false;
    
    // Creates AI
    AIplayer AIturn;
    
    // Header
    cout << "Welcome to Othello!" << endl;
    cout << "the game of Reversi" << endl;
    cout << endl;
    
    // ask for difficulty level
    cout << "What difficulty would you like to play against:" << endl;
    cout << "1) Easy" << endl;
    cout << "2) Hard" << endl;
    cout << "3) 2 Player" << endl;
    cout << "Enter your choice: ";
    cin >> difficulty;
    
    // Error checking for difficulty
    while(cin.fail()){
          
        cin.clear();
        cin.ignore(100, '\n');
        cout << "Invalid selection."<<endl;
        cout << "What difficulty would you like to play against:" << endl;
        cout << "1) Easy" << endl;
        cout << "2) Hard" << endl;
        cout << "3) 2 Player" << endl;
        cout << "Enter your choice: ";
        cin >> difficulty;
        
    }
    
    // start the game
    displayBoard board;// Brand new board
    
    board.start();
    board.printBoard();
    Cell check;
    cout << "X goes first."<<endl;
    
    
    // 
    switch (difficulty) {
        // Easy difficulty
        case 1: {
            do {
                // Player one's move
                if (turn == 1) {
                    // Ask for players move
                    cout << "Enter the (X,Y) coordinates of where you would like to place a chip: " ;
                    cin >> x >> y;
                    // Check fo valid move
                    if(check.isLegalPlacementfor(x, y, board.board, 'X', 'O')){
                        // Player moves
                        board.playerMove1(x,y);
                        // Check for flips in every direction
                        board.upCheck(x, y, 'X', true);
                        board.downCheck(x, y, 'X', true);
                        board.leftCheck(x, y, 'X', true);
                        board.rightCheck(x, y, 'X', true);
                        
                        board.uprightCheck(x, y,'X', true);
                        board.upleftCheck(x, y,'X', true);
                        board.downrightCheck(x, y,'X', true);
                        board.downleftCheck(x, y,'X', true);
        
                        // Change to player 2
                        turn++;
                        
                    }else{
                        cout << "Invalid Move!"<<endl;
                        
                    }
                    
                    // Player two's Move
                } else if (turn == 2) {
                    AImove = AIturn.move1(board);
                    aiX = AImove.first;
                    aiY = AImove.second;
                    //Check fo valid move
                    if(check.isLegalPlacementfor(aiX, aiY, board.board, 'O', 'X')){
                        // Player moves
                        board.playerMove2(aiX,aiY);
                        // Check for flips in every direction
                        board.upCheck(aiX,aiY, 'O', true);
                        board.downCheck(aiX,aiY, 'O', true);
                        board.leftCheck(aiX,aiY, 'O', true);
                        board.rightCheck(aiX,aiY, 'O', true);
                        
                        board.uprightCheck(aiX,aiY,'O', true);
                        board.upleftCheck(aiX,aiY,'O', true);
                        board.downrightCheck(aiX,aiY,'O', true);
                        board.downleftCheck(aiX,aiY,'O', true);
        
                        //Change to player 1
                        turn--;
                        
                    }else{
                        // Prints invalid and then asks for another move
                        cout << "Invalid Move!"<<endl;
                        
                    }
                    
                }
                board.printBoard();
                
            } while (winner == false);
            
        }
            break;
        // Hard difficulty
        case 2: {
            do {
                // Player one's move
                if (turn == 1) {
                    // Ask for players move
                    cout << "Enter the (X,Y) coordinates of where you would like to place a chip: " ;
                    cin >> x >> y;
                    // Check fo valid move
                    if(check.isLegalPlacementfor(x, y, board.board, 'X', 'O')){
                        // Player moves
                        board.playerMove1(x,y);
                        // Check for flips in every direction
                        board.upCheck(x, y, 'X', true);
                        board.downCheck(x, y, 'X', true);
                        board.leftCheck(x, y, 'X', true);
                        board.rightCheck(x, y, 'X', true);
                        
                        board.uprightCheck(x, y,'X', true);
                        board.upleftCheck(x, y,'X', true);
                        board.downrightCheck(x, y,'X', true);
                        board.downleftCheck(x, y,'X', true);
        
                        // Change to player 2
                        turn++;
                        
                    }else{
                        cout << "Invalid Move!"<<endl;
                        
                    }
                    
                    // Player two's Move
                } else if (turn == 2) {
                    AImove = AIturn.move2(board);
                    aiX = AImove.first;
                    aiY = AImove.second;
                    // Check fo valid move
                    if(check.isLegalPlacementfor(aiX, aiY, board.board, 'O', 'X')){
                        // Player moves
                        board.playerMove2(aiX,aiY);
                        // Check for flips in every direction
                        board.upCheck(aiX,aiY, 'O', true);
                        board.downCheck(aiX,aiY, 'O', true);
                        board.leftCheck(aiX,aiY, 'O', true);
                        board.rightCheck(aiX,aiY, 'O', true);
                        
                        board.uprightCheck(aiX,aiY,'O', true);
                        board.upleftCheck(aiX,aiY,'O', true);
                        board.downrightCheck(aiX,aiY,'O', true);
                        board.downleftCheck(aiX,aiY,'O', true);
        
                        // Change to player 1
                        turn--;
                        
                    }else{
                        // Prints invalid and then asks for another move
                        cout << "Invalid Move!"<<endl;
                        
                    }
                    
                }
                board.printBoard();
                
            } while (winner == false);
            
        }
            break;
        // Two player
        case 3: {
            do {
                // Ask for players move
                cout << "Enter the (X,Y) coordinates of where you would like to place a chip: " ;
                cin >> x >> y;
                
                // Player one's move
                if (turn == 1) {
                    // Check fo valid move
                    if(check.isLegalPlacementfor(x, y, board.board, 'X', 'O')){
                        // Player moves
                        board.playerMove1(x,y);
                        // Check for flips in every direction
                        board.upCheck(x, y, 'X', true);
                        board.downCheck(x, y, 'X', true);
                        board.leftCheck(x, y, 'X', true);
                        board.rightCheck(x, y, 'X', true);
                        
                        board.uprightCheck(x, y,'X', true);
                        board.upleftCheck(x, y,'X', true);
                        board.downrightCheck(x, y,'X', true);
                        board.downleftCheck(x, y,'X', true);
        
                        // Change to player 2
                        turn++;
                        
                    }else{
                        cout << "Invalid Move!"<<endl;
                        
                    }
                    
                    // Player two's Move
                } else if (turn == 2) {
                    // Check fo valid move
                    if(check.isLegalPlacementfor(x, y, board.board, 'O', 'X')){
                        // Player moves
                        board.playerMove2(x,y);
                        // Check for flips in every direction
                        board.upCheck(x, y, 'O', true);
                        board.downCheck(x, y, 'O', true);
                        board.leftCheck(x, y, 'O', true);
                        board.rightCheck(x, y, 'O', true);
                        
                        board.uprightCheck(x,y,'O', true);
                        board.upleftCheck(x,y,'O', true);
                        board.downrightCheck(x,y,'O', true);
                        board.downleftCheck(x,y,'O', true);
        
                        // Change to player 1
                        turn--;
                        
                    }else{
                        // Prints invalid and then asks for another move
                        cout << "Invalid Move!"<<endl;
                        
                    }
                }
                board.printBoard();
                
            } while (winner == false); 
        }
            break;
        
    }
 
    
    
    return 0;
}