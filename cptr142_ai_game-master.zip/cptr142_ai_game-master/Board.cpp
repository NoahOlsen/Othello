#include <iostream>
#include <vector>
#include "Board.h"

using namespace std;

// Place starting pieces
void displayBoard::start() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            board[i][j] = ' ';
        }
    }
    // The rest of the board has random data in it possible including X and O
    board[4-1][4-1] = {'X'};
    board[5-1][4-1] = {'O'};
    board[5-1][5-1] = {'X'};
    board[4-1][5-1] = {'O'};
}

// Place X's pieces
void displayBoard::playerMove1(int x, int y) {
    board[x-1][y-1] = {'X'};
  
}

// Place O's pieces
void displayBoard::playerMove2(int x, int y) {
        board[x-1][y-1] = {'O'};
        
}

// Prints the board 
void displayBoard::printBoard() {
    cout << "    1   2   3   4   5   6   7   8 " << endl;
    cout << "  +---+---+---+---+---+---+---+---+ "<< endl;
    for (int j=0; j<8; j++) {
        cout << j+1 << " |";
        
        for (int i=0; i<8; i++) {
            if (isalpha(board[i][j])) {
                cout << " " << board[i][j] << " |";
            } else {
                 cout << board[i][j] << "  |";
            }
        }
        cout << endl << "  +---+---+---+---+---+---+---+---+ "<< endl;
    }
}


void displayBoard::downCheck(int x, int y, char chip, bool change) { // function for checking and changing chips in a line going down
    x -= 1;
    y -= 1;
    int firstY = y;
    int secondY;
    bool addChip = false;
    this->difference = 0;

    for (int i = firstY + 1; i < 8; i++) { // loop that goes down from the origin and finds the first chip of the same character 
        if (board[x][i] == chip) {
          secondY = i;
          if (0 <= secondY < 8) {
              addChip = true;
          }
          break;
        }
    }
    
    if (addChip == true) {
        this->difference = (secondY - firstY) - 1; // the difference will be the amount of chips that are being flipped
        
        for (int i = firstY; i <= secondY; i++) {
            if (board[x][i] == 'X' || board[x][i] == 'O') { // loop that checks if there are any spaces between the two points that 
                                                            // doesnt have a chip in it
            } else { 
                change = false;
            }
        }
        
        if (change == true) {
            for (int i = firstY; i <= secondY; i++) { // loop that goes through the line, changing the chips
                if (board[x][i] == 'X' || board[x][i] == 'O') {
                    board[x][i] = {chip};
                }
            }
        }
    }
}

void displayBoard::upCheck(int x, int y, char chip, bool change) {  // function for checking and changing chips in a line going up
    x -= 1;
    y -= 1;
    int firstY;
    int secondY = y;
    bool addChip = false;
    this->difference = 0;
    
    for (int i = secondY - 1; i >= 0; i--) { // loop that goes down from the origin and finds the first chip of the same character 
        if (board[x][i] == chip) {
          firstY = i;
          if (0 <= firstY < 8) {
              addChip = true;
          }
          break;
        }
    }
    
    if (addChip == true) {
        this->difference = (secondY - firstY) - 1; // the difference will be the amount of chips that are being flipped
        
        for (int i = firstY; i <= secondY; i++) {
            if (board[x][i] == 'X' || board[x][i] == 'O') { // loop that checks if there are any spaces between the two points that 
                                                            // doesnt have a chip in it
            } else { 
                change = false;
            }
        }
        
        if (change == true) {

            for (int i = firstY; i <= secondY; i++) { // loop that goes through the line, changing the chips
                if (board[x][i] == 'X' || board[x][i] == 'O') {
                    board[x][i] = {chip};
                }
            }
        }
    }    
}

void displayBoard::leftCheck(int x, int y, char chip, bool change) {  // function for checking and changing chips in a line going left
    x -= 1;
    y -= 1;
    int firstX;
    int secondX = x;
    bool addChip = false;
    this->difference = 0;
    
    
    for (int i = secondX - 1; i >= 0; i--) { // loop that goes down from the origin and finds the first chip of the same character
        if (board[i][y] == chip) {
          firstX = i;
          if (0 <= firstX < 8) {
              addChip = true;
          }
          break;
        }
    }
    
    if (addChip == true) {
        this->difference = (secondX - firstX) - 1; // the difference will be the amount of chips that are being flipped
        
        for (int i = firstX; i <= secondX; i++) {
            if (board[i][y] == 'X' || board[i][y] == 'O') { // loop that checks if there are any spaces between the two points that 
                                                            // doesnt have a chip in it
            } else {
                change = false;
            }
        }
        
        if (change == true) {
            
            for (int i = firstX; i <= secondX; i++) { // loop that goes through the line, changing the chips
                if (board[i][y] == 'X' || board[i][y] == 'O') {
                    board[i][y] = {chip};
                }    
            }
        }
    }
}

void displayBoard::rightCheck(int x, int y, char chip, bool change) {  // function for checking and changing chips in a line going right
    x -= 1;
    y -= 1;
    int firstX = x;
    int secondX;
    bool addChip = false;
    this->difference = 0;
    
    
    
    for (int i = firstX + 1; i < 8; i++) { // loop that goes down from the origin and finds the first chip of the same character
        if (board[i][y] == chip) {
          secondX = i;
          if (0 <= secondX < 8) {
              addChip = true;
          }
          break;
        }
    }
    
    if (addChip == true) {
        this->difference = (secondX - firstX) - 1; // the difference will be the amount of chips that are being flipped
        
        for (int i = firstX; i <= secondX; i++) {
            if (board[i][y] == 'X' || board[i][y] == 'O') { // loop that checks if there are any spaces between the two points that 
                                                            // doesnt have a chip in it
            } else {
                change = false;
            }
        }
        
        if (change == true) {
            
            for (int i = firstX; i <= secondX; i++) { // loop that goes through the line, changing the chips
                if (board[i][y] == 'X' || board[i][y] == 'O') {
                    board[i][y] = {chip};
                }    
            }
        }
    }
}

void displayBoard::downleftCheck(int x,int y,char chip, bool change) {  // function for checking and changing chips in a line going diagonally down and to the left
    x -= 1;
    y -= 1;
    int firstX = x;
    int firstY = y;
    int secondX;
    int secondY;
    bool addChip = false;
    this->difference = 0;
    
    
    for (int i = 1; i < 8; i++) {
        if (board[firstX - i][firstY + i] == chip) { // loop that goes down from the origin and finds the first chip of the same character
            secondX = firstX - i;
            secondY = firstY + i;
            if (secondX >= 0 && secondX < 8 && secondY >= 0 && secondY < 8) {
                addChip = true;
            }
            break;
        }
    }
    
    if (addChip == true) {
        this->difference = (firstX - secondX) - 1; // the difference will be the amount of chips that are being flipped
        
        int temp = firstX - secondX;
        
            for(int i = 1; i < temp; i++) { // loop that checks if there are any spaces between the two points that doesnt have a chip in it
                if (board[firstX - i][firstY + i] == 'X' || board[firstX - i][firstY + i] == 'O') {

                } else {
                    change = false;
                }
            }    
                
        if (change == true){
            int temp = firstX - secondX;
        
            for(int i = 1; i < temp; i++) { // loop that goes through the line, changing the chips
                if (board[firstX - i][firstY + i] == 'X' || board[firstX - i][firstY + i] == 'O') {
                    board[firstX - i][firstY + i] = {chip};
                }
            }
        }
    }
}
    
void displayBoard::upleftCheck(int x, int y, char chip, bool change) {  // function for checking and changing chips in a line going up and to the left
    x -= 1;
    y -= 1;
    int firstX = x;
    int firstY = y;
    int secondX;
    int secondY;
    bool addChip = false;
    this->difference = 0;
    
    
    for (int i = 1; i < 8; i++) {
        if (board[firstX - i][firstY - i] == chip) { // loop that goes down from the origin and finds the first chip of the same character
            secondX = firstX - i;
            secondY = firstY - i;
            if (secondX >= 0 && secondX < 8 && secondY >= 0 && secondY < 8) {
                addChip = true;
            }
            break;
        }
    }
    
    if (addChip == true) {
        this->difference = (firstX - secondX) - 1; // the difference will be the amount of chips that are being flipped
        
        int temp = firstX - secondX;
            
            for(int i = 1; i < temp; i++) { // loop that checks if there are any spaces between the two points that doesnt have a chip in it
                if (board[firstX - i][firstY - i] == 'X' || board[firstX - i][firstY - i] == 'O') {
                     
                } else {
                    change = false;
                }
            }    
                
        if (change == true){
            int temp = firstX - secondX;
            
            for(int i = 1; i < temp; i++) { // loop that goes through the line, changing the chips
                if (board[firstX - i][firstY - i] == 'X' || board[firstX - i][firstY - i] == 'O') {
                    board[firstX - i][firstY - i] = {chip};
                }
            }
        }
    }
}

void displayBoard::downrightCheck(int x, int y, char chip, bool change) {  // function for checking and changing chips in a line going down and to the right
    x -= 1;
    y -= 1;
    int firstX = x;
    int firstY = y;
    int secondX;
    int secondY;
    bool addChip = false;
    this->difference = 0;
    
    
    for (int i = 1; i < 8; i++) {
        if (board[firstX + i][firstY + i] == chip) { // loop that goes down from the origin and finds the first chip of the same character
            secondX = firstX + i;
            secondY = firstY + i;
            if (secondX >= 0 && secondX < 8 && secondY >= 0 && secondY < 8) {
                addChip = true;
            }
            break;
        }
    }
    
    if (addChip == true) {
        this->difference = (secondX - firstX) - 1; // the difference will be the amount of chips that are being flipped
        
        int temp = secondX - firstX;
            
            for(int i = 1; i < temp; i++) { // loop that checks if there are any spaces between the two points that doesnt have a chip in it
                if (board[firstX + i][firstY + i] == 'X' || board[firstX + i][firstY + i] == 'O') {
                    
                } else {
                    change = false;
                }
            }    
        
        if (change == true){
            int temp = secondX - firstX;
            
            for(int i = 1; i < temp; i++) { // loop that goes through the line, changing the chips
                if (board[firstX + i][firstY + i] == 'X' || board[firstX + i][firstY + i] == 'O') {
                    board[firstX + i][firstY + i] = {chip};
                }
            }
        }
    }
} 

void displayBoard::uprightCheck(int x,int y,char chip, bool change) {  // function for checking and changing chips in a line going up and to the right
    x -= 1;
    y -= 1;
    int firstX = x;
    int firstY = y;
    int secondX;
    int secondY;
    bool addChip = false;
    this->difference = 0;
    
    
    for (int i = 1; i < 8; i++) {
        if (board[firstX + i][firstY - i] == chip) { // loop that goes down from the origin and finds the first chip of the same character
            secondX = firstX + i;
            secondY = firstY - i;
            if (secondX >= 0 && secondX < 8 && secondY >= 0 && secondY < 8) {
                addChip = true;
            }
            break;
        }
    }
    
    if (addChip == true) {
        this->difference = (secondX - firstX) - 1; // the difference will be the amount of chips that are being flipped
        
        int temp = secondX - firstX;
            
            for(int i = 1; i < temp; i++) { // loop that checks if there are any spaces between the two points that doesnt have a chip in it
                if (board[firstX + i][firstY - i] == 'X' || board[firstX + i][firstY - i] == 'O') {
                    
                } else {
                    change = false;
                }
            }
            
        if (change == true){
            int temp = secondX - firstX;
            
            for(int i = 1; i < temp; i++) { // loop that goes through the line, changing the chips
                if (board[firstX + i][firstY - i] == 'X' || board[firstX + i][firstY - i] == 'O') {
                    board[firstX + i][firstY - i] = {chip};
                }
            }
        }
    }
}




