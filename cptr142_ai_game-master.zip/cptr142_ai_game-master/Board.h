#ifndef BOARD_H
#define BOARD_H
#include <iostream>
#include <vector>
using namespace std;

class displayBoard {
    
  public: 
    void start();
    void playerMove1(int x, int y);
    void playerMove2(int x, int y);
    void printBoard();
    int getDifference() { return difference; }
    
    // Vertical and horizontal checks
    void downCheck(int x, int y, char chip, bool change);
    void upCheck(int x, int y, char chip, bool change);
    void leftCheck(int x, int y, char chip, bool change);
    void rightCheck(int x, int y, char chip, bool change);
    
    // diagonal checks
    void upleftCheck(int x, int y, char chip, bool change); 
    void downleftCheck(int x, int y, char chip, bool change);
    void uprightCheck(int x, int y, char chip, bool change);
    void downrightCheck(int x, int y, char chip, bool change);
    char board[8][8] = {};
        
  private:
    int difference = 0; // count for the total chips being turned in a move
    int x;
    int y;
  
  
  
};
#endif