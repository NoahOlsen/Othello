#include <cstdlib>
#include <utility>
#include "Board.h"
#include "Cell.h"
using namespace std;

class displayBoard;
class Cell;
class AIplayer {
    public:
        pair<int, int> move1(displayBoard AImove); // easy move
        pair<int, int> move2(displayBoard AImove); // hard move mutator
    private: // not used
        
        
};
