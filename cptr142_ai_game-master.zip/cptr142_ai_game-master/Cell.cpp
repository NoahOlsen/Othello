#include <iostream>
#include <stdexcept>
#include <vector>
#include <cassert>
#include "Cell.h"
using namespace std;

bool Cell::isLegalPlacementfor(int x, int y, char board[][8], char playDisc, char oppDisc) {
    vector<Directions> directions;

    Cell current(x - 1, y - 1);
    
    if (current.isOccupied(board, playDisc) || current.isOccupied(board, oppDisc)) {
        return false;
    }
    Cell north(x - 1, y - 2);
    if (north.isOccupied(board, oppDisc)) {
        directions.push_back(north.NORTH);
    }
    Cell northEast(x, y - 2);
    if (northEast.isOccupied(board, oppDisc)) {
        directions.push_back(northEast.NORTHEAST);
    }
    Cell east(x, y - 1);
    if (east.isOccupied(board, oppDisc)) {
        directions.push_back(EAST);

    }
    Cell southEast(x, y);
    if (southEast.isOccupied(board, oppDisc)) {
        directions.push_back(SOUTHEAST);

    }
    Cell south(x - 1, y);
    if (south.isOccupied(board, oppDisc)) {
        directions.push_back(SOUTH);

    }
    Cell southWest(x - 2, y);
    if (southWest.isOccupied(board, oppDisc)) {
        directions.push_back(SOUTHWEST);

    }
    Cell west(x - 2, y - 1);
    if (west.isOccupied(board, oppDisc)) {
        directions.push_back(WEST);
    }
    Cell northWest(x - 2, y - 2);
    if (northWest.isOccupied(board, oppDisc)) {
        directions.push_back(NORTHWEST);

    }
    // for (int i = 0; i < directions.size(); i++) {
    //     cout << directions.at(i) << endl;
    // }
    for (auto direction : directions) {
        
        try{
            int value = current.sequenceLength(direction, board, oppDisc, "");
            if (value > 0) {
                return true;
            }
        }
        catch(runtime_error &excpt) {
            //cout << excpt.what() << endl;
        }
    }
    return false;
}

int Cell::sequenceLength(Directions direction, char board[][8], char playDisc, string indent) {
    int x1, y1;
    switch (direction) {
        case NORTH:
            x1 = x;
            y1 = y - 1;
            break;
        case NORTHEAST:
            x1 = x + 1;
            y1 = y - 1;
            break;
        case EAST:
            x1 = x + 1;
            y1 = y;
            break;
        case SOUTHEAST:
            y1 = y + 1;
            x1 = x + 1;
            break;
        case SOUTH:
            x1 = x;
            y1 = y + 1;
            break;
        case SOUTHWEST:
            y1 = y + 1;
            x1 = x - 1;
        case WEST:
            x1 = x - 1;
            y1 = y;
            break;
        case NORTHWEST:
            y1 = y - 1;
            x1 = x - 1;
            break;
        default:
            exit(1);
    }

    if (x1 < 0 || x1 >= 8 || y1 < 0 || y1 >= 8) {
        throw runtime_error("Invalid Sequence");
    }
    Cell sequence(x1, y1);
    if (board[x1][y1] == ' ') {
        throw runtime_error("Invalid Input");
    }

    if (board[x1][y1] != playDisc) {
        return 0;
    }
    int result = (1 + sequence.sequenceLength(direction, board, playDisc, "   " + indent));
    return result;
}

bool Cell::isOccupied(char board[][8], char disc) {
    return (board[x][y] == disc);
}
