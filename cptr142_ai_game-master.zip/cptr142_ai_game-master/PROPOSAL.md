# CPTR 142: Project 3 Proposal
## Problem Definition

The goal for this system is for a player to be able to play against an intelligent A.I. opponent. There will be varying levels of difficulty. The higher the difficulty, the A.I. will make more intelligent moves.

__Key Features__
```
-Text based game of Othello
-A.I to play against
    -3 levels of A.I. to play against(easy, medium, hard)
    -ability to check moves and make "smart" decisions
```


__Assumptions__
```
-assume that the player knows how to play the game(and make valid legal moves)
    -there will be error checking to ensure that the game doesn't break

```


## Group Members
```
*Michael Stacy
*Danny Rippe
*Jason Riggs
*Noah Olsen
```