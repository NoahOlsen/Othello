#  CPTR 142: Project 3 Specifications
## Classes UML Diagram

![UML Diagram](https://1drv.ms/u/s!AuJvymoNpqjkiUbgPIjpJN2HxPxR)

## User Interface Design
```
- Ask user for seed for random number generating
    - Prompt user for what difficulty they would like to play
        - Ask for user to make a move
        - AI player moves and is displayed
        - this process is repeated until players run out of chips
```

## Anticapated Challenges
```
- Checking to see if players move is a valid move
    - We will have to come up with an efficiant search method to look at all the pieces on the board
- If time allows we would like to try and output the board graphically (possibly look into using VNC)
```

## Project Management Plan 
```
-Michael Stacy: Write code for movement error checking 
-Danny Rippe: Write code for movement error checking
-Jason Riggs: User interface and AI/Graphic help
-Noah Olsen: Displaying the board 

```